# CIPM Exam Map (IAPP Body of Knowledge 4.2.0)

Praxis's own orientation reference. It is not an IAPP document and does not reproduce one. It holds a few facts and short descriptions in Praxis's own words, so Praxis can say which part of the exam a question belongs to. For anything finer, the official Body of Knowledge and Exam Blueprint are the authority.

## Source and currency

- Source: IAPP, "CIPM Body of Knowledge and Exam Blueprint", version 4.2.0, effective 1 September 2025 (supersedes 4.1.0). Read on 23 November 2026 at iapp.org/certify/cipm.
- IAPP refreshes exam forms every year, so this version may no longer be the current one. Before relying on it, confirm the version against the official document, and check it against the date of the user's exam.
- If the user supplies the official Body of Knowledge (attached or pasted), use that over this file wherever they differ, and say that you are doing so.

## The six domains

The question ranges are the minimum and maximum number of items per domain given in the blueprint. The one-line orientations are Praxis's own reading of the domain titles, not IAPP wording.

| Domain | Title | Questions (min to max) | Orientation |
|---|---|---|---|
| I | Privacy Program: Developing a Framework | 14 to 18 | The groundwork of a program: what it is for, what it covers and how it is structured |
| II | Privacy Program: Establishing Program Governance | 12 to 16 | Who owns what: roles, accountability, policies and oversight |
| III | Privacy Program Operational Life Cycle: Assessing Data | 12 to 16 | Finding out what personal data the organization holds and where risk sits |
| IV | Privacy Program Operational Life Cycle: Protecting Personal Data | 9 to 13 | The controls, safeguards and training that protect personal data |
| V | Privacy Program Operational Life Cycle: Sustaining Program Performance | 7 to 9 | Keeping the program effective over time: monitoring, measurement and review |
| VI | Privacy Program Operational Life Cycle: Responding to Requests and Incidents | 10 to 14 | Handling individual requests and incidents |

Domains III to VI form the operational life cycle. The total number of scored questions, the duration and the passing score are not given here. Do not state them unless you have checked them against IAPP's current candidate information.

## How Praxis uses this file

1. Name the domain. When explaining a question, say which domain it tests, using the table above.
2. Stay inside the evidence. For detail below domain level, use the user's copy of the official Body of Knowledge, or look it up when web search is available. Otherwise say that the detail comes from general knowledge and should be checked.
3. Do not guess exam facts. Do not state pass marks, question totals, fees or scheduling rules from memory.
4. Keep practice material original. Write your own practice questions. Do not reproduce, request or reconstruct real exam questions or "dumps".
5. Keep the unofficial status clear. Praxis is an independent study aid, not affiliated with or endorsed by IAPP, and it does not give legal advice. IAPP and its certification names belong to IAPP.
